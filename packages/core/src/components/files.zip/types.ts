export type Arrayable<T> = T | T[]

export type ComponentDir =
  | string
  | {
      /**
       * Directory(ies) to scan for local components.
       * Resolved relative to the project root (Vite's `root`).
       * @default 'src/components'
       */
      dirs: string | string[]

      /**
       * File extensions considered as components.
       * @default ['vue']
       */
      extensions?: string | string[]

      /**
       * Globs to exclude from the scan.
       * @default ['**\/node_modules/**', '**\/.git/**']
       */
      exclude?: string[]

      /**
       * When `true`, the component name is prefixed with its folder path
       * (e.g. `base/Button.vue` -> `BaseButton`). When `false`, only the
       * file name is used (e.g. `Button.vue` -> `Button`).
       * @default true
       */
      pathPrefix?: boolean

      /**
       * Renaming function: receives the absolute path of the component file
       * and the default PascalCase name computed from that path, and must
       * return the final name to recognize in templates.
       *
       * - Return a string: use it as the final name.
       * - Return `undefined`: keep the default name.
       * - Return `false`: exclude this component from auto-import.
       *
       * @example
       * // Prefix every component under a "base" folder
       * componentName: (filePath, defaultName) =>
       *   filePath.includes('/base/') ? `Base${defaultName}` : defaultName
       *
       * @example
       * // Explicit rename for a specific component
       * componentName: (filePath, defaultName) => {
       *   const overrides = { MyButton: 'AppButton' }
       *   return overrides[defaultName] ?? defaultName
       * }
       */
      componentName?: (
        filePath: string,
        defaultName: string,
      ) => string | false | undefined
    }

export interface Options {
  /**
   * Directory(ies) to scan for local components.
   * Resolved relative to the project root (Vite's `root`).
   * @default 'src/components'
   */
  dirs?: Arrayable<ComponentDir>

  /**
   * File extensions considered as components.
   * @default ['vue']
   */
  extensions?: string | string[]

  /**
   * Globs to exclude from the scan.
   * @default ['**\/node_modules/**', '**\/.git/**']
   */
  exclude?: string[]

  /**
   * When `true`, the component name is prefixed with its folder path.
   * @default true
   */
  pathPrefix?: boolean

  /**
   * Renaming function: receives the absolute path of the component file
   * and the default PascalCase name computed from that path, and must
   * return the final name to recognize in templates.
   *
   * - Return a string: use it as the final name.
   * - Return `undefined`: keep the default name.
   * - Return `false`: exclude this component from auto-import.
   *
   * @example
   * // Prefix every component under a "base" folder
   * componentName: (filePath, defaultName) =>
   *   filePath.includes('/base/') ? `Base${defaultName}` : defaultName
   *
   * @example
   * // Explicit rename for a specific component
   * componentName: (filePath, defaultName) => {
   *   const overrides = { MyButton: 'AppButton' }
   *   return overrides[defaultName] ?? defaultName
   * }
   */
  componentName?: (
    filePath: string,
    defaultName: string,
  ) => string | false | undefined

  /**
   * Generates a TypeScript declaration file listing the detected local
   * components (useful for template auto-completion). `true` writes to
   * 'components.d.ts' at the project root, or pass a custom path.
   * `false` disables it. Note: only locally scanned components are
   * included; components resolved via `resolvers` are not (they are
   * resolved lazily per-file, not known ahead of time).
   * @default 'components.d.ts'
   */
  dts?: boolean | string

  /** Enables debug logging to the console. @default false */
  verbose?: boolean
}

/** Fully resolved version of a `ComponentDir` entry, ready to be scanned. */
export interface ResolvedComponentDir {
  dirs: string[]
  extensions: string[]
  exclude: string[]
  pathPrefix: boolean
  componentName?: (filePath: string, defaultName: string) => string | false | undefined
}

/** Fully resolved plugin options. */
export interface ResolvedOptions {
  root: string
  dirs: ResolvedComponentDir[]
  dts: string | false
  verbose: boolean
}

/** Metadata about a single discovered component. */
export interface ComponentInfo {
  name: string
  /** Absolute path to the component file. */
  path: string
  /** File extension, without the leading dot. */
  ext: string
}
