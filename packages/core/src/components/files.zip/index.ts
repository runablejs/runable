import { createUnplugin } from 'unplugin'
import { AutoImportContext } from './core/context'
import { resolveOptions } from './core/options'
import { shouldTransform, transformCode } from './core/transform'
import type { Options } from './types'

export * from './types'

export default createUnplugin<Options | undefined>((rawOptions = {}) => {
  let ctx: AutoImportContext | undefined

  return {
    name: 'unplugin-auto-components',
    enforce: 'pre',

    vite: {
      configResolved(config) {
        const options = resolveOptions(rawOptions ?? {}, config.root)
        ctx = new AutoImportContext(options)
      },
    },

    async buildStart() {
      // Fallback for non-Vite consumers of this unplugin, where
      // `vite.configResolved` never runs.
      if (!ctx) ctx = new AutoImportContext(resolveOptions(rawOptions ?? {}, process.cwd()))
      await ctx.init()
    },

    transformInclude(id) {
      return !!ctx && shouldTransform(id, ctx)
    },

    async transform(code, id) {
      if (!ctx) return null
      const result = transformCode(code, id, ctx)
      if (!result) return null
      return { code: result.code, map: result.map }
    },

    watchChange(id, change) {
      void ctx?.handleWatchChange(id, change.event)
    },
  }
})
