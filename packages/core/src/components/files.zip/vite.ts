import unplugin from './index'

export * from './types'
export default unplugin.vite
