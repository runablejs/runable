# unplugin-auto-components

Auto-import de composants locaux pour Vite (Vue SFC + JSX/TSX), construit sur
`unplugin` et `@babel/parser` / `@babel/traverse` pour l'analyse du code.

## Installation

```bash
npm i -D unplugin-auto-components
```

## Usage

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoComponents from 'unplugin-auto-components/vite'

export default defineConfig({
  plugins: [
    vue(),
    AutoComponents({
      dirs: [
        'src/components',
        { dirs: 'src/components/base', pathPrefix: false }, // Button.vue -> Button
      ],
      extensions: ['vue'],
      dts: 'src/components.d.ts',
      verbose: true,
    }),
  ],
})
```

## Fonctionnement

1. **Scan** (`core/scan.ts`) — au démarrage de Vite, chaque `dirs` configuré
   est parcouru avec `fast-glob` pour construire une table
   `nom de composant -> chemin absolu`. Le nom par défaut est calculé en
   PascalCase à partir du chemin (`base/my-button.vue` -> `BaseMyButton`),
   avec support de `pathPrefix`, de `componentName()` et détection des
   doublons.

2. **Détection d'usage** (`core/transform.ts`), à chaque fichier transformé
   par Vite :
   - **`.vue`** : le bloc `<template>` est scanné avec une regex légère pour
     en extraire les noms de balises (`core/vue-sfc.ts`), sans dépendre du
     compilateur Vue. Chaque tag (`my-button` ou `MyButton`) est comparé à la
     table de composants. Le bloc `<script>`/`<script setup>` est ensuite
     parsé avec Babel (`@babel/parser` + `@babel/traverse`) pour lister les
     identifiants déjà liés (imports, `const`, fonctions...) et ne pas les
     réimporter.
   - **`.js/.jsx/.ts/.tsx`** : le fichier entier est parsé avec Babel, et
     tout `JSXOpeningElement` dont le nom commence par une majuscule et n'est
     lié par aucune déclaration de portée (`scope.getAllBindings()`) est
     considéré comme un composant potentiel.

3. **Injection** (`core/transform.ts`) — l'import est injecté avec
   `magic-string`, pas en régénérant le fichier via un codegen Babel complet :
   cela préserve le formatage d'origine et produit une sourcemap précise à
   moindre coût.
   - `.vue` avec `<script setup>` : import injecté en tête de bloc, aussitôt
     utilisable dans le template (résolution automatique de Vue).
   - `.vue` sans `<script>` : un bloc `<script setup>` est créé avant le
     `<template>`.
   - `.vue` avec un `<script>` classique (Options API) : l'import est ajouté
     en tête ; il reste à la charge du composant de le référencer dans
     `components: {}` si nécessaire (l'auto-résolution complète de
     l'Options API demanderait de réécrire l'objet exporté, volontairement
     hors scope ici pour rester simple et prévisible).
   - `.js/.jsx/.ts/.tsx` : import ajouté après le dernier `import` de tête de
     fichier.

4. **`components.d.ts`** (`core/dts.ts`) — régénéré après chaque scan
   (initial + changements de fichiers), en augmentant
   `GlobalComponents` de `vue`. L'écriture est court-circuitée si le contenu
   n'a pas changé, pour éviter tout bruit HMR inutile.

5. **Watch** (`core/context.ts`) — le hook `watchChange` d'unplugin
   déclenche un nouveau scan uniquement sur `create`/`delete` de fichiers
   situés dans un dossier surveillé et portant une extension configurée (un
   simple `update` de contenu ne change jamais la table nom -> chemin).

## Limites connues

- La détection de tags dans le `<template>` est basée sur une regex, pas sur
  le compilateur Vue : elle ignore le contenu des commentaires HTML, mais ne
  comprend pas la structure complète du template (ex: un tag écrit
  dynamiquement via `<component :is="...">` n'est évidemment pas détecté,
  comme dans la plupart des solutions équivalentes).
- Pour l'Options API (`<script>` sans `setup`), l'import est ajouté mais pas
  câblé automatiquement dans `components: {}`.
- La détection de bindings existants dans les fichiers `.vue`/JSX repose sur
  `scope.getAllBindings()` au niveau du `Program` : un composant masqué par
  une variable locale dans une fonction imbriquée ne sera pas détecté comme
  "déjà lié" (edge case rare, à documenter si besoin).

## Build

```bash
npm run build   # tsup -> dist/{index,vite}.{js,cjs,d.ts}
```
